package com.example.myappbdsw;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class DetallesMedActivity extends AppCompatActivity {
    private TextView idTxt, nombreTxt, cantidadTxt, precioTxt, fechaTxt;
    private String id, nombre, cantidad, precio, fecha;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles_med);
        idTxt=findViewById(R.id.txtID);
        nombreTxt=findViewById(R.id.txtNombre);
        cantidadTxt=findViewById(R.id.txtCantidad);
        precioTxt=findViewById(R.id.txtPrecio);
        fechaTxt=findViewById(R.id.txtFecha);
        traerDatos();
    }


    public void traerDatos(){
        Bundle bundle = getIntent().getExtras();
        id = String.valueOf(bundle.getInt("id"));
        idTxt.setText("No. ID : "+id);

        nombre=bundle.getString("nombre");
        nombreTxt.setText(nombre);

        cantidad=String.valueOf(bundle.getInt("cantidad"));
        cantidadTxt.setText(cantidad);

        precio=String.valueOf(bundle.getDouble("precio"));
        precioTxt.setText("Q"+precio);

        fecha=bundle.getString("fecha");
        fechaTxt.setText(fecha);


    }
}
