package com.example.myappbdsw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.NetworkError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.myappbdsw.modeloVO.Medicamento;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MostrarActivity extends AppCompatActivity implements Response.Listener<JSONObject>, Response.ErrorListener {
    private ListView lista;
    RequestQueue requestQueue;
    JsonObjectRequest jsonObjectRequest;
    ArrayList<String> listaDatos;
    ArrayList<Medicamento> listaMedicamento;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar);

        lista = findViewById(R.id.listaMostrar);
        requestQueue = Volley.newRequestQueue(this);
        consultaCompletaSW();

    }


    public void consultaCompletaSW(){
        String url;
        url = InsertarActivity.IP_SERVER+"/php_sw/mostrarsw.php";
        jsonObjectRequest= new JsonObjectRequest(Request.Method.GET,url,null,this,this);
        requestQueue.add(jsonObjectRequest);


    }

    @Override
    public void onErrorResponse(VolleyError error) {
        if (error instanceof TimeoutError) {
            Toast.makeText(this, "error_network_timeout", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ServerError) {
            Toast.makeText(this, "error_server", Toast.LENGTH_SHORT).show();
        } else if (error instanceof NetworkError) {
            Toast.makeText(this, "network error", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ParseError) {
            Toast.makeText(this, "parse error", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "algun otro error", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onResponse(JSONObject response) {
        Medicamento medicamento = null;
        //Obtencion de la respuesta de los registros obtenidos por la consulta de PHP
        JSONArray jsonArray = response.optJSONArray("medicamentos");
        listaMedicamento = new ArrayList<>();
        try {
            for (int i= 0; i<jsonArray.length(); i++){
                medicamento = new Medicamento();
                //se define para poder cargar la informacion ya en el arreglo de respuesta
                JSONObject jsonObject = null;
                //se le asigna cada informacion por recorrido
                jsonObject = jsonArray.getJSONObject(i);

                //se agrega cada registro relacionado a los campos
                medicamento.setId(jsonObject.optInt("id"));
                medicamento.setNombre_medicamento(jsonObject.optString("nombre_medicamento"));
                medicamento.setCantidad(jsonObject.optInt("cantidad"));
                medicamento.setPrecio(jsonObject.optDouble("precio"));
                medicamento.setFecha_vencimiento(jsonObject.optString("fecha_vencimiento"));

                listaMedicamento.add(medicamento);
            }

            listaDatos = new ArrayList<>();
            for (int i = 0; i<listaMedicamento.size(); i++ ){

                listaDatos.add(listaMedicamento.get(i).getNombre_medicamento());

            }

            ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,listaDatos);
            lista.setAdapter(adapter);
            lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    //  Toast.makeText(MainActivity.this, "A pulsado "+datos.get(position), Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(getApplicationContext(), DetallesMedActivity.class);
                    intent.putExtra("id", listaMedicamento.get(position).getId());
                    intent.putExtra("nombre", listaMedicamento.get(position).getNombre_medicamento());
                    intent.putExtra("cantidad", listaMedicamento.get(position).getCantidad());
                    intent.putExtra("precio", listaMedicamento.get(position).getPrecio());
                    intent.putExtra("fecha", listaMedicamento.get(position).getFecha_vencimiento());
                    startActivity(intent);
                }
            });

        }catch (Exception e){
            Toast.makeText(this, ""+e, Toast.LENGTH_SHORT).show();

        }
    }
}
